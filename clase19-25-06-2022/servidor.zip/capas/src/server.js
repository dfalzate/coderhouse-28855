import express from 'express';
import datosRouter from './routers/datos.routers.js';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/datos', datosRouter);

const PORT = process.env.PORT || 8080;
const server = app.listen(PORT, () => {
	console.log(`----------------------------------------------`);
	console.log(`Server started on http://localhost:${PORT} ✨`);
	console.log(`----------------------------------------------`);
});
server.on('error', (err) => console.log(err));
