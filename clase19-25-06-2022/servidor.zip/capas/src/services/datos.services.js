const datos = [];

export function addDatos(data) {
	datos.push(data);
}

export function getDatos() {
	return datos;
}
